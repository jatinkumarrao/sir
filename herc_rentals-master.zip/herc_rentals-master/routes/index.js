  
var express = require('express')
  , routes = express.Router()
  , http = require('http')
  , path = require('path'), 
  multer = require('multer')
    , bodyParser=require("body-parser");

var router = express.Router();


 const DIR = './public/';

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.toLowerCase().split(' ').join('-');
    cb(null, fileName)
  }
});

// Multer Mime Type Validation
var upload = multer({
  storage: storage,
});

message="";
router.get('/create', function(req, res) {
    res.render('create', message);
});

router.get('/list', function(req, res) {
req.getConnection(function(error, connection) {
   connection.query('SELECT * FROM `softwares` ', function(error, results, fields) {
      if (error) throw error;
    res.render('list',{title:"Details",
    data:results,status:'success'
})
})

})
});
router.post('/upload',upload.single('profile'), function (req, res) {
   req.getConnection(function(error, connection) {
  message : "Error! in image upload."
  const url = req.protocol + '://' + req.get('host')
    const   avatar= url + '/public/' + req.file.filename;
    if (!req.file) {
        console.log("No file received");
          message = "Error! in image upload."
        res.render('create',{message});
   
      } else {
        const data = { file_name: req.file.filename, name: req.body.name,description:req.body.description};
connection.query('INSERT INTO softwares SET ?', data, (error, results) => {
  if(error) throw error;
 return res.redirect('/');
});
}     
})
 })

router.get('/search',function(req,res){
   res.render('search');
});
router.post('/search',function(req,res){
req.getConnection(function(error, connection) {
   connection.query('SELECT * FROM `softwares` where name like "%'+req.body.search+'%"', function(error, results, fields) {
      if (error) throw error;
    res.render('search',{title: req.body.search,
    data:results,color:'success',status:'There are no records available'
})
})

})
})

module.exports = router;