var config = {
	database: {
		host:	  'localhost', 	// database host
		user: 	  'root', 		// your database username
		password: '', 		// your database password
		db: 	  'herc_rentals' 		// your database name
	}
}

module.exports = config
