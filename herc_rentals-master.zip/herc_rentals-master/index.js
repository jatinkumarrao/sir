var express = require('express')
  , routes = express.Router()
  , http = require('http')
  , path = require('path')
  , app = express(),
  multer = require('multer')
  
  , bodyParser=require("body-parser");
var mysql = require('mysql')
 
var routes = require('./routes/index'); 
var myConnection  = require('express-myconnection')
var config = require('./config/config')
var dbOptions = {
  host:     config.database.host,
  user:     config.database.user,
  password: config.database.password,
  database: config.database.db
}

app.use(myConnection(mysql, dbOptions, 'pool'))


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));



// all environments
const PORT =8080;
app.set('port',8080);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));
app.use('/public', express.static('public'));

app.use('/', routes);
data ='';
title="";
status="";
error="";
color="";
app.get('/', function(req, res) {
    res.render('search',data,color,title,status);
});


 app.listen(PORT, function () {
  console.log('Node.js server is running on port ' + PORT);
});
