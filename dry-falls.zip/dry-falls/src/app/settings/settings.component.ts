import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { AlertService } from '../../services/alert.service';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  myform: FormGroup;
  user;

  constructor( 
  	private loader : Ng4LoadingSpinnerService, 
  	public alert : AlertService,
  	private _settings : SettingsService) 
  	{ 
  		
  		var userObject = localStorage.getItem('user');
    	var user = JSON.parse(userObject);
    	this.user = user;
    	this.getSettings();
  }

  ngOnInit() {

  	this.myform = new FormGroup({
        
        from_name: new FormControl('', [ 
            Validators.required
        ]),
        from_email: new FormControl('', [ 
            Validators.required,
            Validators.pattern("[^ @]*@[^ @]*") 
        ]),
        reply_to: new FormControl('', [ 
            Validators.required,
            Validators.pattern("[^ @]*@[^ @]*") 
        ])
         
    });

  }

  getSettings(){

  	this.loader.show();
  	this._settings.getSettings(this.user._id).subscribe(
        data => {
        	if(data){
        		this.myform.controls['from_name'].setValue(data.from_name);
        		this.myform.controls['from_email'].setValue(data.from_email);
        		this.myform.controls['reply_to'].setValue(data.reply_to);
        	}
        	this.loader.hide();
        },
        err => {
        	console.error(err);
        	this.loader.hide();
        }
    );
 
  }

  saveSettings(){
 
  	this._settings.updateSettings(this.user._id,this.myform.value).subscribe(
        data => {
        	this.alert.setMessage('Settings saved successfully', 'success');
        	this.loader.hide();
        },
        err => {
        	this.loader.hide();
        	if('error' in err &&  err.error.message){
	          this.alert.setMessage(err.error.message, 'danger');
	        }
        	console.error(err);
        	
        }
    );

  }

}
