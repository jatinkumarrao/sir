import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { EmailTemplateService } from '../../../services/email-template.service';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-email-template-listing',
  templateUrl: './email-template-listing.component.html',
  styleUrls: ['./email-template-listing.component.css']
})
export class EmailTemplateListingComponent implements OnInit {

  pageSize:number = 12;
  templates = [];
  totalRecords:number;
  user:any;

  constructor(private template: EmailTemplateService, public alert : AlertService, private loader : Ng4LoadingSpinnerService) { 

  	var userObject = localStorage.getItem('user');
    this.user = JSON.parse(userObject);
    this.getUserTemplates(1);

  }

  ngOnInit() {
  }


    getUserTemplates(page: number){
      
      this.loader.show();

      let start = (page - 1) * this.pageSize;
     
      this.template.getTemplates(this.user._id, start, this.pageSize).subscribe(
          res => {
            this.loader.hide();
            this.templates = [];
            for(let t of res.data){
            	var template = JSON.parse(t.data);
            	this.templates.push({_id : t._id, data : template }); 
            }
            this.totalRecords = res.totalTemplates;
            
          },
          err => {
            this.loader.hide();
            console.error(err)
              
          }
      ); 
       
    } 

}
