import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailTemplateListingComponent } from './email-template-listing.component';

describe('EmailTemplateListingComponent', () => {
  let component: EmailTemplateListingComponent;
  let fixture: ComponentFixture<EmailTemplateListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailTemplateListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailTemplateListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
