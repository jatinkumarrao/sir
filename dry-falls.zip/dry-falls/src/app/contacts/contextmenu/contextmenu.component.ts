import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-contextmenu',
  templateUrl: './contextmenu.component.html',
  styleUrls: ['./contextmenu.component.css']
})
export class ContextmenuComponent implements OnInit {
  
  @Input() x = 0;
  @Input() y = 0;
  @Input() index:number;
  @Input() data:any;

  @Output() delete = new EventEmitter();
  @Output() edit = new EventEmitter();

  constructor() { }

  ngOnInit() { }

  editElement(){
  	this.edit.emit(this.data);
  }

  deleteElement(){
  	this.delete.emit(this.index);
  }



}
