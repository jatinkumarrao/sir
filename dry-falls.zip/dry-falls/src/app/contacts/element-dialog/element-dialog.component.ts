import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';

import { ContactService } from '../../../services/contact.service';
import { API_ENDPOINT } from '../../../config'

@Component({
  selector: 'app-element-dialog',
  templateUrl: './element-dialog.component.html',
  styleUrls: ['./element-dialog.component.css']
})

export class ElementDialogComponent implements OnInit {

  textData:string;
  showGallery:boolean = false;
  user:any;
  images = [];
  API_URL: string = API_ENDPOINT;
  imageSrc:string;

  public uploader:FileUploader = new FileUploader({
      url: this.API_URL+'/upload',
      method: "POST",
  });
   

  constructor(
    public dialogRef: MatDialogRef<ElementDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _contactService: ContactService)
  { 

  }

  ngOnInit() {

    var userObject = localStorage.getItem('user');
    this.user = JSON.parse(userObject);

    this.getUserImages();

    this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };

    this.uploader.onBuildItemForm = (fileItem: any, form: any) => {
      form.append('user_id',this.user._id);
    };

    this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
        var data = JSON.parse(response)
        this.images.unshift(data.image);
    };

    if(this.data.item.type == 'image'){
      const item = Object.assign({}, this.data.item);
      this.imageSrc = item.src;

    }

    this.textData = this.data.item.html;

  }

  textChangeEvent(e){
    //this.data.item.html = this.textData;
  }

  close(){

    if(this.data.item.type == 'image'){
      this.data.item.src = this.imageSrc;
    }

    this.data.item.html = this.textData;
    this.dialogRef.close(this.data);

  }

  openGallery(){
    this.showGallery = true;
  }

  closeGallery(){
    this.showGallery = false;
  }

  uploadFile(){
    this.uploader.uploadAll();

  }

  getUserImages(){
 
    this._contactService.getUserImages(this.user._id).subscribe(
        res => {
          this.images = res.data;
        },
        err => {
           console.error(err)
        }
    ); 
     
  }

  selectImage(image){

    var src = this.API_URL +'/uploads/'+image;
    this.imageSrc = src;
    this.showGallery = false;

  }

}
