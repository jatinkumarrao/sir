import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.css']
})
export class WidgetComponent implements OnInit {

  @Input() data:any;

  constructor() { 
  }

  ngOnInit() {

  	console.log('here',this.data);

  }

}
