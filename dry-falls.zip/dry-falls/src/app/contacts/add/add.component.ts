import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ContactService } from '../../../services/contact.service';
import { AlertService } from '../../../services/alert.service';
 

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})

export class AddComponent implements OnInit {

  myform: FormGroup;
  alertMessage:string;
  alertMessageType:string;
  user:any;

  constructor(private _contactService: ContactService, private router: Router, public alert : AlertService) { 
      var userObject = localStorage.getItem('user');
      this.user = JSON.parse(userObject);
  }

  ngOnInit() {

  	this.myform = new FormGroup({
         
        first_name: new FormControl('', [ 
            //Validators.required
        ]),
        last_name: new FormControl('', [ 
            //Validators.required
        ]),
        email: new FormControl('', [ 
            Validators.required,
            Validators.pattern("[^ @]*@[^ @]*") 
        ]),
        mobile: new FormControl('', [ 
            //Validators.required
        ]),
        subscribed : new FormControl('yes', [ 
            Validators.required
        ])
         
    });
    

  }

  create(){

  	this._contactService.addUserContacts(this.user._id,this.myform.value).subscribe(
  		data => { 
  			this.myform.reset();
        this.alert.setMessage('Contacts Added successfully', 'success');
        this.router.navigate(['/contacts']);

  		},
  		err => {
  			if('error' in err &&  err.error.message){
          this.alert.setMessage(err.error.message, 'danger');
  			}
  			console.error('error', err)
  		} 
	  ); 

  }


}
