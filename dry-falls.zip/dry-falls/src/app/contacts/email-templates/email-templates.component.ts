import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material";
import {Router, ActivatedRoute, Params} from '@angular/router';

import { ElementDialogComponent } from '../element-dialog/element-dialog.component';
import { EmailTemplateService } from '../../../services/email-template.service';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-email-templates',
  templateUrl: './email-templates.component.html',
  styleUrls: ['./email-templates.component.css']
})

export class EmailTemplatesComponent implements OnInit {

  user:any;
  contextmenu = false;
  contextmenuX = 0;
  contextmenuY = 0;
  currentIndex:number;
  currentItem:any;
  currentItemType:string;
  childIndex:number;
  id:string;

  @HostListener('document:click')
  
  clickout() {
    this.contextmenu = false;
  }

  droppedItems:any = [];
  	
  	items = [
        {name : 'Button', type: "button", html : "s"},
        {name : 'Text', type: "text", html:'dummy text...'},
        {name : 'Image', type: "image", src:'assets/images/placeholder-image.jpg'},
        {name : 'Two columns', type: "two-columns"}
    ];
  
  onItemDrop(e: any) { 

    const item = Object.assign({}, e.dragData);
    this.droppedItems.push(item);

  }

  onItemChild(e: any, index:number, box:string){
    
    e.dragData.box = box;
    const item = Object.assign({}, e.dragData);

    if('childs' in this.droppedItems[index]){
        this.droppedItems[index].childs.push(item);
    }
    else {
      this.droppedItems[index].childs = [item];
    }
     
  }

  constructor(private dialog: MatDialog, 
      private template : EmailTemplateService,  
      private route: ActivatedRoute,
      private router : Router,
      private alert : AlertService) 
    { 
    var userObject = localStorage.getItem('user');
    this.user = JSON.parse(userObject);
    
    this.route.params.subscribe( params => {
       
        if(params.id){
          this.id = params.id;
          this.getTemplate()
        }
    });

  }

  ngOnInit() {

  }
  
  editElement(element){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '800px';
    dialogConfig.height = '600px';

    dialogConfig.data = {
        type : this.currentItemType, 
        index : this.currentIndex,
        childIndex : this.childIndex,
        item : this.currentItem
    };
 
    let dialogRef = this.dialog.open(ElementDialogComponent, dialogConfig);
    
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.droppedItems[this.currentIndex].html = result.item.html; 
    });

  }
 

  deleteElement(index:number){
    
    if(this.currentItemType == 'child'){
        var items = this.droppedItems[index].childs;
        items.splice(this.childIndex,1);
        this.droppedItems[index].childs =items;
    }
    else{

      if('childs' in this.droppedItems[index]){
        this.droppedItems[index].childs = [];
      }

      this.droppedItems.splice(index,1);

      console.log(this.items);

    }

  }


  onRightClick(event, index:number, item, type:string, childIndex:number) {
     
    event.stopPropagation();
    this.currentItemType = type; 
    this.currentIndex = index;
    this.childIndex = childIndex;
    this.currentItem = item;
    this.contextmenuX = event.clientX;
    this.contextmenuY = event.clientY;
    this.contextmenu = true;
    return false;

  }

  saveTemplate(){

    if(!this.droppedItems.length){
       alert('Can\'t save empty template');
       return false;
    }
    var data = { content : this.droppedItems};

    this.template.addTemplate(this.user._id,data).subscribe(
      data => {
        this.alert.setMessage('Template Added successfully', 'success');
        this.router.navigate(['/contacts/email-templates']);

      },
      err => {
        if('error' in err &&  err.error.message){
          //this.alert.setMessage(err.error.message, 'danger');
        }
        console.error('error', err)
      } 
    ); 

  }

  getTemplate(){

      this.template.getTemplate(this.id).subscribe(
          res => {
            var template = JSON.parse(res.data);
            this.droppedItems = template;
          },
          err => {
             console.error(err)
              
          }
      ); 
       
  } 


  updateTemplate(){

    if(!this.droppedItems.length){
       alert('Can\'t save empty template');
       return false;
    }
    var data = { content : this.droppedItems};

    this.template.updateTemplate(this.id,data).subscribe(
      data => {
        this.alert.setMessage('Template updated successfully', 'success');
        this.router.navigate(['/contacts/email-templates']);

      },
      err => {
        console.error('error', err)
      } 
    ); 

  }

}
