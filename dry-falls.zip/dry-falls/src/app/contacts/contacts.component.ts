import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as XLSX from 'xlsx';
import {Sort} from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { ContactService } from '../../services/contact.service';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {
	
	  contacts = [];
	  alertMessage:string;
    alertMessageType:string;
    pageSize:number = 20;
    totalRecords:number = 0;
    isLoaded = false;
    user:any;
    searchForm: FormGroup;
    selecteAllContacts:boolean = false;
    selectedContacts:number = 0;
    deleteID = 0;

  	constructor(private _contactService: ContactService, public alert : AlertService, private loader : Ng4LoadingSpinnerService) { 
      
      var userObject = localStorage.getItem('user');
      this.user = JSON.parse(userObject);
       
      this.searchForm = new FormGroup({
          q: new FormControl('', [ 
            Validators.required
          ])
      });

      this.getUserContacts(1);

    }

  	ngOnInit() {}

    pageChanged(page: number) {

      this.getUserContacts(page);

    }

    changePageSize(){
        this.getUserContacts(1); 
    }

    getUserContacts(page: number){
      this.loader.show();
      let start = (page - 1) * this.pageSize;
      let q = this.searchForm.value.q;
      
      this._contactService.getUserContacts(this.user._id, start, this.pageSize, q).subscribe(
          res => {
            this.loader.hide();
            if('data' in res){
              this.contacts = res.data;
              this.totalRecords = res.totalContacts;
            }
            this.isLoaded = true;
          },
          err => {
            console.error(err)
            this.isLoaded = true;
            this.loader.hide();
          }
      ); 
       
    } 

    searchContacts(){

      this.getUserContacts(1);

    }

    
    sortData(sort: Sort) {


        const data = this.contacts.slice();
        if (!sort.active || sort.direction == '') {
          this.contacts = data;
          return;
        }

        this.contacts = data.sort((a, b) => {
        let isAsc = sort.direction == 'asc';
        switch (sort.active) {
            case 'first_name': return this.compare(a.first_name.toLocaleLowerCase(), b.first_name.toLocaleLowerCase(), isAsc);
            case 'last_name': return this.compare(a.last_name.toLocaleLowerCase(), b.last_name.toLocaleLowerCase(), isAsc);
            case 'email': return this.compare(a.email.toLocaleLowerCase(), b.email.toLocaleLowerCase(), isAsc);
            case 'mobile': return this.compare(a.mobile.toLocaleLowerCase(), b.mobile.toLocaleLowerCase(), isAsc);
            case 'created_at': return this.compare(a.created_at.toLocaleLowerCase(), b.created_at.toLocaleLowerCase(), isAsc);
            default: return 0;
          }
        });

    }

    compare(a, b, isAsc) {
      return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
 

    export(type = '') {
      
      var header = ['Email','First Name', 'Last Name', 'Mobile','Subscribed','Added At','Updated At'];
      var allContacts = [];
      var selectedContacts = [];

      allContacts.push(header);
      selectedContacts.push(header);

      if(type == 'all'){

          this._contactService.getUserContacts(this.user._id, 0, 1000000 , '').subscribe(
            res => {
              this.loader.hide();
              if(res.data.length){
                  res.data.forEach(function(contact) {
                    var data = [
                      contact.email,
                      contact.first_name,
                      contact.last_name,
                      contact.mobile,
                      contact.subscribed,
                      contact.created_at,
                      contact.updated_at
                    ];

                    allContacts.push(data);
              
                  });

                  const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(allContacts, {cellDates:true});
                  const wb: XLSX.WorkBook = XLSX.utils.book_new();
                  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
                  XLSX.writeFile(wb, 'contacts.xlsx');

              }
            },
            err => {
              console.error(err)
              this.isLoaded = true;
              this.loader.hide();
            }
        ); 

      }
      else{

          this.contacts.forEach(function(contact) {
              var data = [
                contact.email,
                contact.first_name,
                contact.last_name,
                contact.mobile,
                contact.subscribed,
                contact.created_at,
                contact.updated_at
              ];

              if(contact.selected){
                  selectedContacts.push(data);
              }
              allContacts.push(data);
        
          });
          
          if(selectedContacts.length > 1){
            var exportData = selectedContacts;
          }
          else{
            var exportData = allContacts;
          }

          const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(exportData, {cellDates:true});
          const wb: XLSX.WorkBook = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
          XLSX.writeFile(wb, 'contacts.xlsx');

      }
       
    }

    selectAll(){
      let type = this.selecteAllContacts;
      this.selectedContacts = 0;

      if(type){
        this.selectedContacts = this.contacts.length;
      }

      this.contacts.forEach(function(contact) {
          contact.selected = type;
      });

    }

    selectAction(type){

      this.selectedContacts = (type) ? this.selectedContacts + 1 : this.selectedContacts - 1;

      if(this.selectedContacts != this.contacts.length){
        this.selecteAllContacts = false;
      }
      else{
        this.selecteAllContacts = true;
      }

    }

    bulkDelete(){

      let data = [];
      this.contacts.forEach(function(contact) {
          if(contact.selected){
            data.push(contact._id);
          }
      });

      if(!data.length){
        alert('Please select at least one contact');
        return false;
      }

      this.loader.show();
      this._contactService.deleteMany(data).subscribe(
            data => {
              this.loader.hide();
              this.alert.setMessage('Contacts successfully deleted', 'success');
              this.getUserContacts(1);
            },
            err => {
              console.error(err)
              this.loader.hide();
            } 
      ); 

    }


    confirmDelete(contact) : void{
        this.deleteID = contact._id;
    }

    delete() : void  {

      if(this.deleteID){

        this.loader.show();
        this._contactService.deleteContact(this.deleteID).subscribe(
            data => {
              this.alert.setMessage('Contacts successfully deleted', 'success');
              this.getUserContacts(1);
              this.loader.hide();
              this.deleteID = 0;
            },
            err => {
              console.error(err);
              this.loader.hide();
            }
        ); 
      
      }

    }

    sendEmail(){

        this._contactService.sendEmail(1).subscribe(
            data => {
              this.alert.setMessage('Email sent successfully', 'success');
            },
            err => console.error(err)
        ); 

    }

}
