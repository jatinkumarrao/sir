import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { UpdateProfileComponent } from './auth/update-profile/update-profile.component';
import { AuthGuardService } from '../services/auth-guard.service';
//import { ContactsModule } from './contacts/contacts.module';
import { CampaignComponent } from './campaign/campaign.component';
import { ListComponent } from './list/list.component';
import { AddListComponent } from './list/add-list/add-list.component';
import { EditListComponent } from './list/edit-list/edit-list.component';
import { AddCampaignComponent } from './campaign/add-campaign/add-campaign.component';
import { EditCampaignComponent } from './campaign/edit-campaign/edit-campaign.component';
import { SettingsComponent } from './settings/settings.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';

import { ContactsComponent } from './contacts/contacts.component';
import { ImportComponent } from './contacts/import/import.component';
import { AddComponent } from './contacts/add/add.component';
import { EditComponent } from './contacts/edit/edit.component';
import { EmailTemplatesComponent } from './contacts/email-templates/email-templates.component';
import { EmailTemplateListingComponent } from './contacts/email-template-listing/email-template-listing.component';
import { CampaignHistoryComponent } from './campaign/campaign-history/campaign-history.component';


const app_routes: Routes = [

  { path: '', pathMatch: 'full', redirectTo: 'welcome' },
  { path: 'welcome', component : WelcomeComponent},
  { path: 'auth/login', component : LoginComponent},
  { path: 'auth/forgot-password', component : ForgotPasswordComponent},
  { path: 'auth/reset-password/:token', component : ForgotPasswordComponent},
  { path: 'auth/signup',component : SignupComponent},
  { path: 'auth/update-profile',component : UpdateProfileComponent, canActivate : [AuthGuardService]},
  { path: 'auth/change-password',component : ChangePasswordComponent, canActivate : [AuthGuardService]},
  { path: 'campaigns',component : CampaignComponent, canActivate : [AuthGuardService]},
  { path: 'campaigns/add',component : AddCampaignComponent, canActivate : [AuthGuardService]},
  { path: 'campaigns/edit/:id',component : EditCampaignComponent, canActivate : [AuthGuardService]},
  { path: 'campaigns/copy/:copyfrom',component : EditCampaignComponent, canActivate : [AuthGuardService]},
  { path: 'campaigns/history/:id',component : CampaignHistoryComponent, canActivate : [AuthGuardService]},
  { path: 'lists',component : ListComponent, canActivate : [AuthGuardService]},
  { path: 'lists/add',component : AddListComponent, canActivate : [AuthGuardService]},
  { path: 'lists/edit/:id',component : EditListComponent, canActivate : [AuthGuardService]},
  { path: 'settings',component : SettingsComponent, canActivate : [AuthGuardService]},
  //{ path: 'contacts', loadChildren :  './contacts/contacts.module#ContactsModule' },
  //{ path: 'contacts', loadChildren : () => ContactsModule },
  { path: 'contacts', component: ContactsComponent, canActivate : [AuthGuardService] },
  //{ path: 'email-templates', component: EmailTemplatesComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/email-templates', component: EmailTemplateListingComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/import/:listid', component: ImportComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/import', component: ImportComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/add', component: AddComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/edit/:id', component: EditComponent , canActivate : [AuthGuardService] },
  { path: 'contacts/template/:id', component: EmailTemplatesComponent , canActivate : [AuthGuardService]},
  { path: 'contacts/template', component: EmailTemplatesComponent , canActivate : [AuthGuardService]}
   
];

@NgModule({
  imports: [ RouterModule.forRoot(app_routes) ],
  exports: [ RouterModule ]
})

export class AppRoutingModule { }
