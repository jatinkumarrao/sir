import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
//import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { MatCardModule,MatSortModule, MatDialogModule,MatTableModule, MatDatepickerModule,MatNativeDateModule } from '@angular/material';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';
import { NgDragDropModule } from 'ng-drag-drop';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { PaginationModule } from './shared/pagination/pagination.module';

import { ContactService } from '../services/contact.service';
import { AuthService } from '../services/auth.service';
import { AuthGuardService } from '../services/auth-guard.service';
import { AlertService } from '../services/alert.service';
import { ListService } from '../services/list.service';
import { CampaignService } from '../services/campaign.service';
import { SettingsService } from '../services/settings.service';
import { EmailTemplateService } from '../services/email-template.service';


import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { UpdateProfileComponent } from './auth/update-profile/update-profile.component';
import { CampaignComponent } from './campaign/campaign.component';
import { ListComponent } from './list/list.component';
import { AddListComponent } from './list/add-list/add-list.component';
import { EditListComponent } from './list/edit-list/edit-list.component';
import { AddCampaignComponent } from './campaign/add-campaign/add-campaign.component';
import { EditCampaignComponent } from './campaign/edit-campaign/edit-campaign.component';
import { SettingsComponent } from './settings/settings.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ContactDialogComponent } from './list/contact-dialog/contact-dialog.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';
import { ScheduleDialogComponent } from './campaign/schedule-dialog/schedule-dialog.component';

import { JoditAngularModule } from 'jodit-angular';
import { FileUploadModule } from 'ng2-file-upload';

import { ContactsComponent } from './contacts/contacts.component';
import { SafeHtmlPipe } from './shared/pipes/safehtml.pipe';

import { ImportComponent } from './contacts/import/import.component';
import { AddComponent } from './contacts/add/add.component';
import { EditComponent } from './contacts/edit/edit.component';
import { EmailTemplatesComponent } from './contacts/email-templates/email-templates.component';
import { ElementDialogComponent } from './contacts/element-dialog/element-dialog.component';
import { WidgetComponent } from './contacts/widget/widget.component';
import { ContextmenuComponent } from './contacts/contextmenu/contextmenu.component';
import { EmailTemplateListingComponent } from './contacts/email-template-listing/email-template-listing.component';
import { CampaignHistoryComponent } from './campaign/campaign-history/campaign-history.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    ChangePasswordComponent,
    UpdateProfileComponent,
    CampaignComponent,
    ListComponent,
    AddListComponent,
    EditListComponent,
    AddCampaignComponent,
    EditCampaignComponent,
    SettingsComponent,
    WelcomeComponent,
    ContactDialogComponent,
    ForgotPasswordComponent,
    ScheduleDialogComponent,
    ContactsComponent,
    ImportComponent,
    AddComponent,
    EditComponent,
    EmailTemplatesComponent,
    ElementDialogComponent,
    WidgetComponent,
    ContextmenuComponent,
    SafeHtmlPipe,
    EmailTemplateListingComponent,
    CampaignHistoryComponent
  ],
  imports: [
    FormsModule, 
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    PaginationModule,
    Ng4LoadingSpinnerModule.forRoot(),
    MatCardModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    AngularDateTimePickerModule,
    JoditAngularModule,
    FileUploadModule,
    NgDragDropModule.forRoot(),
    MatTableModule,
    MatSortModule

  ],
  providers: [
    ContactService,
    AuthService,
    AuthGuardService,
    AlertService,
    ListService,
    CampaignService,
    SettingsService,
    EmailTemplateService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  entryComponents: [ContactDialogComponent, ScheduleDialogComponent, ElementDialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
