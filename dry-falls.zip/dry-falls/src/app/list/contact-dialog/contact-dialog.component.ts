import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { ContactService } from '../../../services/contact.service';
import { ListService } from '../../../services/list.service';

@Component({
  selector: 'app-contact-dialog',
  templateUrl: './contact-dialog.component.html',
  styleUrls: ['./contact-dialog.component.css']
})

export class ContactDialogComponent implements OnInit {
  
  contacts = [];
  AddedContacts = [];
  search:string;

  constructor(
  	private loader : Ng4LoadingSpinnerService,
  	private _list : ListService,
  	public dialogRef: MatDialogRef<ContactDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _contactService: ContactService
  ){ 
  		
  }

  ngOnInit() {

  	this._list.getContacts(this.data.list_id).subscribe(
    	data => { 
		
        if(data){
          for(let contact of data){
			  if(contact.contact_id){
				this.AddedContacts.push(contact.contact_id._id);  
			  }
              
          }
           
        }
        this.getUserContacts();
    	},
    	err => {
        	console.error('error', err)
      }

	  );

  }

    getUserContacts(){
      this.loader.show();
      let pageSize = 1000;
      
      this._contactService.getUserContacts(this.data.user_id, 0, pageSize, '').subscribe(
          res => {
            this.loader.hide();
            if('data' in res){

               if(this.AddedContacts){
               		this.contacts = [];
               		if(res.data.length){
               			 
               			for(let contact of res.data){
               				if(this.AddedContacts.indexOf(contact._id) > -1){
               					contact.selected = true;
               					this.contacts.push(contact);
               				}
               				else{
               					this.contacts.push(contact);
               				}
               			}
               		}

               }
               else{
               	   this.contacts = res.data;
               }
              
            }
          },
          err => {
            console.error(err)
            this.loader.hide();
          }
      ); 
       
    }

    selectAction(contact){

    }



    saveListContacts(){

    	if(this.contacts.length){
    		this.loader.show();
    		var selectedContacts = [];
			for(let contact of this.contacts){
				if(contact.selected){
					selectedContacts.push({ list_id : this.data.list_id, contact_id : contact._id});
				}
			}
    		
    		var postData = { contacts : selectedContacts};

    		this._list.addContacts(this.data.list_id, postData).subscribe(
		    	data => {
		        	this.loader.hide();
		        	this.dialogRef.close({status : true});
		    	},
		    	err => {
		    		this.loader.hide();
		        	console.error('error', err)
		      	}

		    );

    	}

    }


    filterContacts(str){

      this.contacts.filter(contact => {
          contact.hide = true;
          if(contact.first_name.indexOf(str) >=0 ||
            contact.last_name.indexOf(str) >=0 || 
            contact.email.indexOf(str) >=0 
          ){
            contact.hide = false;
          }
          return contact;

      });

    }

}
