import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router} from '@angular/router';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';
import { ListService } from '../../../services/list.service';

@Component({
  selector: 'app-add-list',
  templateUrl: './add-list.component.html',
  styleUrls: ['./add-list.component.css']
})
export class AddListComponent implements OnInit {

   myform: FormGroup;
   user;

  constructor(private router : Router, private auth : AuthService, private loader : Ng4LoadingSpinnerService, public alert : AlertService, private _list : ListService) { 
  	var userObject = localStorage.getItem('user');
    var user = JSON.parse(userObject);
    this.user = user;
  }

  ngOnInit() {

  	this.myform = new FormGroup({
        name: new FormControl('', [ 
            Validators.required
        ])
    });

  }

  addList(){

    this._list.addList(this.user._id,this.myform.value).subscribe(
      data => { 
        this.myform.reset();
        this.alert.setMessage('List Added successfully', 'success');
        this.router.navigate(['/lists']);
      },
      err => {
        if('error' in err &&  err.error.message){
          this.alert.setMessage(err.error.message, 'danger');
        }
        console.error('error', err)
      } 
    ); 

  }

}
