import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MatDialog, MatDialogConfig } from "@angular/material";
import * as XLSX from 'xlsx';
import {Router} from '@angular/router';

import { ContactDialogComponent } from './contact-dialog/contact-dialog.component';

import { AuthService } from '../../services/auth.service';
import { AlertService } from '../../services/alert.service';
import { ListService } from '../../services/list.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  
  pageSize:number = 20;
  totalRecords:number = 0;
  lists:any = [];
  searchForm: FormGroup;
  user;
  selecteAllList:boolean = false;

  constructor(
    private router: Router,
    private auth : AuthService, 
    private loader : Ng4LoadingSpinnerService, 
    public alert : AlertService, 
    private _list : ListService,
    private dialog: MatDialog
    ){ 
  	  var userObject = localStorage.getItem('user');
      var user = JSON.parse(userObject);
      this.user = user;

      this.searchForm = new FormGroup({
        q: new FormControl('', [ 
          Validators.required
        ])
      });

      this.getLists(1);
  }

  ngOnInit() {

  }

  pageChanged(page: number) {
      this.getLists(page);
  }

  getLists(page: number){
      this.loader.show();

      let start = (page - 1) * this.pageSize;
      let q = this.searchForm.value.q;
      
      this._list.getLists(this.user._id, start, this.pageSize, q).subscribe(
          res => {
            this.loader.hide();
            if('data' in res){
              this.lists = res.data;
              this.totalRecords = res.totalLists;
            }
          },
          err => {
            console.error(err)
            this.loader.hide();
          }
      ); 
       
  } 

  selectAll(){

    let type = this.selecteAllList;
    this.lists.forEach(function(list) {
      list.selected = type;
    });
  }

  selectAction(type:boolean){
    if(!type){
      this.selecteAllList = false;
    }
  }

  bulkDelete(){

    let data = [];
      this.lists.forEach(function(list) {
          if(list.selected){
            data.push(list._id);
          }
      });

      if(!data.length){
        alert('Please select at least one list');
        return false;
      }

      this.loader.show();
      this._list.deleteMany(data).subscribe(
            data => {
              this.loader.hide();
              this.alert.setMessage('List deleted successfully', 'success');
              this.getLists(1);
            },
            err => {
              console.error(err)
              this.loader.hide();
            } 
      );
       

  }  

  delete(list) : void  {

      if(confirm('Are you sure want to delete?')){
        this.loader.show();
        this._list.deleteList(list._id).subscribe(
            data => {
              this.alert.setMessage('List deleted successfully', 'success');
              this.getLists(1);
              this.loader.hide();
            },
            err => {
              console.error(err);
              this.loader.hide();
            }
        ); 
      }

  }


  addContacts(list){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    //dialogConfig.width = '900px';
    //dialogConfig.height = '600px';

    dialogConfig.data = { list_id : list._id, user_id : this.user._id};
 
    let dialogRef = this.dialog.open(ContactDialogComponent, dialogConfig);
    
    dialogRef.afterClosed().subscribe(result => {
       if(result.status){
          this.getLists(1);
          this.alert.setMessage('Contact added successfully', 'success');
       }
       
    });

  }

  importListContacts(id){

    this.router.navigate(['/contacts/import/', id]);
  }

  exportListContacts(id){
 
    var header = ['Email','First name', 'Last name', 'Mobile','Subscribed','Added at','Updated at'];
    var contacts = [];
    contacts.push(header);
    this.loader.show();

    this._list.getContacts(id).subscribe(
        data => { 

            for(let contact of data){
              var con = [
                contact.contact_id.email,
                contact.contact_id.first_name,
                contact.contact_id.last_name,
                contact.contact_id.mobile,
                contact.contact_id.subscribed,
                contact.contact_id.created_at,
                contact.contact_id.updated_at
              ];
              contacts.push(con);

            }
            this.loader.hide();
            const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(contacts, {cellDates:true});
            // generate workbook and add the worksheet 
            const wb: XLSX.WorkBook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

            // save to file 
            XLSX.writeFile(wb, 'contacts.xlsx');

        },
        err => {
            this.loader.hide();
            console.error('error', err)
        }

    );

  }

}
