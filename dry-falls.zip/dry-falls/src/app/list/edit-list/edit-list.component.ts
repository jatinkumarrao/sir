import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';
import { ListService } from '../../../services/list.service';

@Component({
  selector: 'app-edit-list',
  templateUrl: './edit-list.component.html',
  styleUrls: ['./edit-list.component.css']
})
export class EditListComponent implements OnInit {

  id:string;
  list:any;
  myform: FormGroup;
  isLoaded = false;

  constructor(
  	private router : Router,
  	private route: ActivatedRoute, 
  	private auth : AuthService, 
  	private loader : Ng4LoadingSpinnerService, 
  	public alert : AlertService, 
  	private _list : ListService,

    ){ 
  	 
  	 this.route.params.subscribe( params => {
  		this.id = params.id;
  		this.getContact();
  	});

  }

  ngOnInit() {
  }

  getContact(){
  	this.loader.show();
  	this._list.getList(this.id).subscribe(
        data => {
        	this.list = data;
        	this.createForm();
        	this.isLoaded = true;
        	this.loader.hide();
        },
        err => console.error(err)
    ); 

  }

  createForm(){

  	this.myform = new FormGroup({
        name: new FormControl(this.list.name, [ 
            Validators.required
        ])
    });

  }


  updateList(){

  	this.loader.show();
  	this._list.updateList(this.id,this.myform.value).subscribe(
  		data => { 
  			this.loader.hide();
  			this.alert.setMessage('List Update successfully', 'success');
        	this.router.navigate(['/lists']);
  		},
  		err => {
  			if('error' in err &&  err.error.message){
  				this.alert.setMessage(err.error.message, 'danger');
  			}
  			this.loader.hide();
  			console.error('error', err)
  		} 
	);

  }

}
