import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';
import { CampaignService } from '../../../services/campaign.service';
 

@Component({
  selector: 'app-campaign-history',
  templateUrl: './campaign-history.component.html',
  styleUrls: ['./campaign-history.component.css']
})
export class CampaignHistoryComponent implements OnInit {
  
  	id:string;
  	histories = [];
  	logs = [];
  	pageSize:number = 20;
  	totalRecords:number = 0;
  	showLogData : boolean = false;

  	constructor(
	  	private router : Router,
	  	private route: ActivatedRoute, 
	  	private auth : AuthService, 
	  	private loader : Ng4LoadingSpinnerService, 
	  	public alert : AlertService, 
	  	private _campaign : CampaignService
	){

	  	this.route.params.subscribe( params => {
	    	this.id = params.id;
	     	this.getHistories(1);
	    });

    }

  ngOnInit() {
  }

  	pageChanged(page: number) {

      this.getHistories(page);

    }

  	getHistories(page: number){

  		this.loader.show();
      	let start = (page - 1) * this.pageSize;
	  	this._campaign.getHistories(this.id, start, this.pageSize).subscribe(
	        res => {

	        	if('data' in res){
	              this.histories = res.data;
	              this.totalRecords = res.totalHistory;
	            }
	        	this.loader.hide();
	        },
	        err => { 
	        	console.error(err)
	        	this.loader.hide();
	        }
	    ); 

 	}


 	showLog(history){

 		this.logs = [];
 		this.loader.show();
 		let tag = 'cam_'+history._id;
 		this._campaign.getHistorLog(tag).subscribe(
	        res => {
	        	this.loader.hide();
	        	this.showLogData = true;
	        	for(let log of res.items){
	        		/*
	        		let found = this.logs.find(function(element) {
					  return element.recipient == log.recipient && log.event = 'accepted';
					});

					if(!found){
						this.logs.push({recipient : log.recipient, status : log.event });	
					}	
					*/
					this.logs.push({recipient : log.recipient, status : log.event });
	        		
	        	}
	        	
	        	this.loader.hide();
	        },
	        err => { 
	        	this.loader.hide();
	        	console.error(err)
	        	
	        }
	    ); 


 	}

 	hideLogs(){
 		this.showLogData = false;
 	}

}
