import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router} from '@angular/router';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';
import { CampaignService } from '../../../services/campaign.service';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.css']
})
export class AddCampaignComponent implements OnInit {

   myform: FormGroup;
   user;

  constructor(
  	private router : Router, 
  	private auth : AuthService, 
  	private loader : Ng4LoadingSpinnerService, 
  	public alert : AlertService, 
  	private _campaign : CampaignService
  	){ 
  		var userObject = localStorage.getItem('user');
   		var user = JSON.parse(userObject);
    	this.user = user;
  }

  ngOnInit() {

  	this.myform = new FormGroup({
        name: new FormControl('', [ 
            Validators.required
        ])
    });

  }

  addCampaign(){

    this._campaign.addCampaign(this.user._id,this.myform.value).subscribe(
      data => { 
        this.myform.reset();
        this.alert.setMessage('Campaign Added successfully', 'success');
        this.router.navigate(['/campaigns']);
      },
      err => {
        if('error' in err &&  err.error.message){
          this.alert.setMessage(err.error.message, 'danger');
        }
        console.error('error', err)
      } 
    ); 

  }

}
