import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { ScheduleDialogComponent } from './schedule-dialog/schedule-dialog.component';

import { AuthService } from '../../services/auth.service';
import { AlertService } from '../../services/alert.service';
import { CampaignService } from '../../services/campaign.service';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent implements OnInit {
   
  pageSize:number = 20;
  totalRecords:number = 0;
  campaigns:any = [];
  searchForm: FormGroup;
  user;

  constructor(
    private dialog : MatDialog,
  	private auth : AuthService, 
  	private loader : Ng4LoadingSpinnerService,
  	public alert : AlertService, 
  	private _campaign : 
  	CampaignService) 
  	{ 
  		var userObject = localStorage.getItem('user');
   	 	var user = JSON.parse(userObject);
    	this.user = user;
	    this.searchForm = new FormGroup({
	        q: new FormControl('', [ 
	          Validators.required
	        ])
	    });

	    this.getCampaigns(1);
  }

  ngOnInit() {
  }

  pageChanged(page: number) {
      this.getCampaigns(page);
  }


  getCampaigns(page: number){
      this.loader.show();

      let start = (page - 1) * this.pageSize;
      let q = this.searchForm.value.q;
      
      this._campaign.getCampaigns(this.user._id, start, this.pageSize, q).subscribe(
          res => {
            this.loader.hide();
            if('data' in res){
              this.campaigns = res.data;
              this.totalRecords = res.totalCampaigns;
            }
          },
          err => {
            console.error(err)
            this.loader.hide();
          }
      ); 
       
  } 

  addSchedule(id){

      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.width = '800px';
      dialogConfig.height = '600px';

      dialogConfig.data = { campainid : id };
   
      let dialogRef = this.dialog.open(ScheduleDialogComponent, dialogConfig);
      
      dialogRef.afterClosed().subscribe(result => {
        console.log(result);
      });
      

  }



  delete(campaign) : void  {

      if(confirm('Are you sure want to delete?')){
        this.loader.show();
        this._campaign.deleteCampaign(campaign._id).subscribe(
            data => {
              this.alert.setMessage('Campaign deleted successfully', 'success');
              this.getCampaigns(1);
              this.loader.hide();
            },
            err => {
              console.error(err);
              this.loader.hide();
            }
        ); 
      }

  }


}
