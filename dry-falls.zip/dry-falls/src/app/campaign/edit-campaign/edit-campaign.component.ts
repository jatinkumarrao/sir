import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';
import { CampaignService } from '../../../services/campaign.service';
import { ListService } from '../../../services/list.service';

@Component({
  selector: 'app-edit-campaign',
  templateUrl: './edit-campaign.component.html',
  styleUrls: ['./edit-campaign.component.css']
})

export class EditCampaignComponent implements OnInit {
   
  id:string;
  campaign:any;
  myform: FormGroup;
  isLoaded = false;
  lists;
  selectedList: string;
  user;
  copyName;
  cards;
  toggleOpen : boolean = false;
  campaigForm: FormGroup;
  copy : boolean = false;
  saveAndSend : boolean = false;

  constructor(
  	private router : Router,
  	private route: ActivatedRoute, 
  	private auth : AuthService, 
  	private loader : Ng4LoadingSpinnerService, 
  	public alert : AlertService, 
  	private _campaign : CampaignService,
    private _list : ListService

    ){ 
  	 
      var userObject = localStorage.getItem('user');
      var user = JSON.parse(userObject);
      this.user = user

    	this.route.params.subscribe( params => {
        
        if('copyfrom' in params) {
          this.id = params.copyfrom;
          this.copy = true;
        }
        else{
          this.id = params.id;
        }

    		this.getContact();
        
    	});

      this.cards = { 
        recipients : false,
        from : false,
        subject : false,
        content : false
      };

      this.getLists();

  }

  ngOnInit() {
  }

  getContact(){
  	this.loader.show();
  	this._campaign.getCampaign(this.id).subscribe(
        data => {
             
        	this.campaign = data;
        	this.createForm();
        	this.isLoaded = true;
        	this.loader.hide();
        },
        err => console.error(err)
    ); 

  }

  createForm(){
    
    let name = this.campaign.name;
    if(this.copy){
      this.copyName = name;
      let q = name +' (copy';
      if(name.indexOf('(copy') >=0 ){
          var str = name.split("(copy");
          q = str[0]+'(copy';
          this.copyName = str[0];
      }
      
      this.getCampaignCopyNo(q);
      name = this.campaign.name + ' (copy 01)';
    }

  	this.myform = new FormGroup({
        name: new FormControl(name, [ 
            Validators.required
        ]),
        to: new FormControl(this.campaign.to, [ 
            Validators.required
        ]),
        from_name: new FormControl(this.campaign.from_name, [ 
            Validators.required
        ]),
        from_email: new FormControl(this.campaign.from_email, [ 
            Validators.required
        ]),
        subject: new FormControl(this.campaign.subject, [ 
            Validators.required
        ])
         
    });


    this.campaigForm = new FormGroup({
        tolist: new FormControl(this.campaign.to, [ 
            Validators.required
        ]),
        name: new FormControl(this.campaign.from_name, [ 
            Validators.required
        ]),
        email: new FormControl(this.campaign.from_email, [ 
            Validators.required,
            Validators.pattern("[^ @]*@[^ @]*") 
        ]),
        subject: new FormControl(this.campaign.subject, [ 
            Validators.required
        ]),
        content: new FormControl('', [ 
            Validators.required
        ])

      });

  }


  submitCampaign(){

      if(this.copy){
        this.copyCampaign();
      }
      else{
        this.updateCampaign();
      }
  }


  updateCampaign(){

  	this.loader.show();
  	this._campaign.updateCampaign(this.id,this.myform.value).subscribe(
  		data => { 
  			if(!this.saveAndSend){
                this.loader.hide();
  			    this.alert.setMessage('Campaign Update successfully', 'success');
                this.router.navigate(['/campaigns']);
            }
  		},
  		err => {
  			if('error' in err &&  err.error.message){
  				this.alert.setMessage(err.error.message, 'danger');
  			}
  			this.loader.hide();
  			console.error('error', err)
  		} 
	  );

  }

  copyCampaign(){

    this.loader.show();
    this._campaign.addCampaign(this.user._id,this.myform.value).subscribe(
      data => { 
        this.loader.hide();
        this.alert.setMessage('Campaign copped successfully', 'success');
          this.router.navigate(['/campaigns']);
      },
      err => {
        if('error' in err &&  err.error.message){
          this.alert.setMessage(err.error.message, 'danger');
        }
        this.loader.hide();
        console.error('error', err)
      } 
    );

  }


  getLists(){
      
      this._list.getLists(this.user._id, 0, 1000,'').subscribe(
          res => {
            this.loader.hide();
            if('data' in res){
              this.lists = res.data;
              console.log(this.lists);
            }
          },
          err => {
            console.error(err)
            this.loader.hide();
          }
      ); 
       
  }

  toggleCard(key:string, type:boolean){
      this.cards[key] = type;
      this.toggleOpen = type
  }

  saveCampaig(key:string){
    
    this.toggleOpen = false;
    this.cards[key] = false;
    
    let cards = Object.keys(this.cards);
    let index = cards.indexOf(key);
    index = index+1;

    if(index < cards.length){
      let nextCard = cards[index];
      this.cards[nextCard] = true;
      this.toggleOpen = true;

    }

  }


  getCampaignCopyNo(q){

    this._campaign.getCampaignCopyNo(this.user._id,q).subscribe(
        data => {
          if(data){
            var no = data+1;
            let name = this.copyName + ' (copy '+ '0'+ no+')';
            this.myform.controls['name'].setValue(name);
            console.log(q);
          }
        },
        err => console.error(err)
    ); 

  }

  saveAndSendMail(){
    
    this.saveAndSend = true;

    this.myform.controls['to'].setValue(this.campaigForm.value.tolist);
    this.myform.controls['from_name'].setValue(this.campaigForm.value.name);
    this.myform.controls['from_email'].setValue(this.campaigForm.value.email);
    this.myform.controls['subject'].setValue(this.campaigForm.value.subject);

    this.updateCampaign();
    this.sendMail();
   
    
  }

  sendMail(){
    
    var data = this.campaigForm.value;
    data.content = data.content.replace(/\r\n|\r|\n/g,"<br />");
    data.id = this.id;

    this.loader.show();
    this._campaign.sendMail(data).subscribe(
      data => { 
        //this.campaigForm.reset();
        this.loader.hide();
        this.alert.setMessage('Mail sent successfully', 'success');
        window.scrollTo(0, 0);
        this.saveAndSend = false;
      },
      err => {
        this.loader.hide();
        console.error('error', err)
      } 
    );
   

  }


}
