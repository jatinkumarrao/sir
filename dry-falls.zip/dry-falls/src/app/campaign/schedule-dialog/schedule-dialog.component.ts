import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-schedule-dialog',
  templateUrl: './schedule-dialog.component.html',
  styleUrls: ['./schedule-dialog.component.css']
})
export class ScheduleDialogComponent implements OnInit {
 
  date: Date = new Date();
  settings = {
		bigBanner: true,
		timePicker: true,
		format: 'dd-MM-yyyy',
		defaultOpen: true
	}

  constructor(
  	public dialogRef: MatDialogRef<ScheduleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any)
  { 

  }

  ngOnInit() {

  	console.log(this.data);

  }

  onDateSelect(event){


  }

  close(){
  	
  }

}
