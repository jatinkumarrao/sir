import { Component, OnInit, Inject} from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
//import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  
  myform:FormGroup;
  domain;
  token:string;
  loader: boolean = false;

  constructor(
  	private auth : AuthService, 
  	private router: Router,
  	private route: ActivatedRoute, 
  	public alert : AlertService,  
  	//private loader : Ng4LoadingSpinnerService,
  	@Inject(DOCUMENT) private document: any) { 

  		this.route.params.subscribe( params => {
	  		this.token = params.token;
	  		if(this.token){

	  			this.myform = new FormGroup({
			        password: new FormControl('', [ 
			            Validators.required,
			            Validators.minLength(5)

			        ]),
			        confirmpassword: new FormControl('', [ 
			            Validators.required,
			            this.equalto('password')
			        ])
			         
			    });
	  		}
	  		else {

	  			this.myform = new FormGroup({

			        email: new FormControl('', [ 
			            Validators.required,
			            Validators.pattern("[^ @]*@[^ @]*") 
			        ])
			    });
	  		}
	  	});

  	}

  ngOnInit() {

  	this.domain = this.document.location.hostname;



  }

  resetRequest(){
 
  	this.loader = true;
    
    var data = this.myform.value;
    if(this.domain == 'localhost'){
    	var resetLink = 'http://localhost:4200/#/auth/reset-password';
    }
    else{
    	var resetLink = 'https:'+this.domain+'/#/auth/reset-password';
    }
    
    data.resetLink = resetLink;

    this.auth.forgotPassword(data).subscribe(
        data => { 
          this.loader = false;
          this.alert.setMessage('We have sent a mail to your registered email address, please check and follow the instructions', 'success');
          this.router.navigate(['auth/login']);
        },
        err => {
          this.loader = false;
          if('error' in err &&  err.error.message){
            this.alert.setMessage(err.error.message, 'danger');
          }
          console.error('error', err)
        } 
    ); 

  }

  equalto(field_name) {

    return (control: AbstractControl): {[key: string]: any} => {
    let input = control.value;
    let isValid=control.root.value[field_name]==input;
    if(!isValid)
    return { 'equalTo': {isValid} }
      else
      return null;
    };

  }


  updatePassword(){
 
  	this.loader = true;
  	var data = this.myform.value;
  	data.token = this.token;

  	this.auth.resetPassword(data).subscribe(
    	data => {
      		this.loader = false;
      		this.alert.setMessage('Your password has been updated successfully', 'success');
      		this.router.navigate(['auth/login']);
    	},
    	err => {
      	this.loader = false;
	    	if('error' in err &&  err.error.message){
	        	this.alert.setMessage(err.error.message, 'danger');
	      }
	      console.error('error', err)
    	} 
  	); 
 
  }
   

}
