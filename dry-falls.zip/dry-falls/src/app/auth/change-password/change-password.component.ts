import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  
  myform: FormGroup;
  user;

  constructor(private auth : AuthService, private loader : Ng4LoadingSpinnerService, public alert : AlertService) { 
  	var userObject = localStorage.getItem('user');
    var user = JSON.parse(userObject);
    this.user = user;

  }

  ngOnInit() {

  	this.myform = new FormGroup({
        
        oldpassword: new FormControl('', [ 
            Validators.required
        ]), 
        password: new FormControl('', [ 
            Validators.required,
            Validators.minLength(5)

        ]),
        confirmpassword: new FormControl('', [ 
            Validators.required,
            this.equalto('password')
        ])
         
    });


  }

  equalto(field_name) {

    return (control: AbstractControl): {[key: string]: any} => {
    let input = control.value;
    let isValid=control.root.value[field_name]==input;
    if(!isValid)
    return { 'equalTo': {isValid} }
      else
      return null;
    };

  }

  updatePassword(){
 
  	this.loader.show();
  	var data = this.myform.value;
  	data.email = this.user.email;

  	this.auth.changePassword(this.myform.value).subscribe(
    	data => {
    		this.myform.reset();
      		this.loader.hide();
      		this.alert.setMessage('Your password has been updated successfully', 'success');
    	},
    	err => {
      		this.loader.hide();
	    	if('error' in err &&  err.error.message){
	        	this.alert.setMessage(err.error.message, 'danger');
	      	}
	      	console.error('error', err)
    	} 
  	); 
 
  }


}
