import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';


@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  myform: FormGroup;
  user;

  constructor(private auth : AuthService, private loader : Ng4LoadingSpinnerService, public alert : AlertService) { 
  	var userObject = localStorage.getItem('user');
    var user = JSON.parse(userObject);
    this.user = user;
  }

  ngOnInit() {

  	this.myform = new FormGroup({
        
        first_name: new FormControl(this.user.first_name, [ 
            Validators.required
        ]),
        last_name: new FormControl(this.user.last_name, [ 
            Validators.required
        ])
         
    });

  }


  updateProfile(){

  	var userdata = this.myform.value;
  	userdata.id = this.user._id;
  	this.loader.show();

  	this.auth.updateProfile(userdata).subscribe(
  		res => {  
  			this.loader.hide();
  			localStorage.setItem('user', JSON.stringify(res.data));
  			this.alert.setMessage('Your profile has been updated successfully', 'success');
  		},
  		err => {
  			this.loader.hide();
  			if('error' in err &&  err.error.message){
  				this.alert.setMessage(err.error.message, 'danger');
  			}
  			console.error('error', err)
  		} 
	); 

  }

}
