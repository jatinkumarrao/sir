import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
//import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import {Router} from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  myform: FormGroup;
  alertMessage:string;
  alertMessageType:string;
  passwordType:string = 'password';
  loader: boolean = false;

  constructor(
    private auth : AuthService, 
    private router: Router, 
    //private loader : Ng4LoadingSpinnerService,
    public alert : AlertService) {

      var userObject = localStorage.getItem('user');
      var user = JSON.parse(userObject);
      if(user){
        //this.auth.setLoginStatus(true);
        this.router.navigate(['/contacts']);
      }
 
  }

  ngOnInit() {

  	this.myform = new FormGroup({
         
        email: new FormControl('', [ 
            Validators.required,
            Validators.pattern("[^ @]*@[^ @]*") 
        ]),
        password: new FormControl('', [ 
            Validators.required
        ])
         
    });

  }

  changePasswordType(){
     
    this.passwordType = (this.passwordType == 'password') ? 'text' : 'password';
    
  }

  login(){

      this.loader = true;
      this.auth.login(this.myform.value).subscribe(
        data => { 
          this.loader = false;
          localStorage.setItem('user', JSON.stringify(data));
          this.auth.setLoginStatus(true);
          this.router.navigate(['/contacts']);

        },
        err => {
          this.loader = false;
          if('error' in err &&  err.error.message){
            this.alert.setMessage(err.error.message, 'danger');
          }
          console.error('error', err)
        } 
      ); 

  }


}
