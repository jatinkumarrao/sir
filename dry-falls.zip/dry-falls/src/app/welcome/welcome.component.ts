import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-welcome',
  template: ''
})

export class WelcomeComponent implements OnInit {

  constructor(private router: Router, private auth : AuthService) {

  	  var userObject = localStorage.getItem('user');
      var user = JSON.parse(userObject);
      
      if(user){
        this.auth.setLoginStatus(true);
        this.router.navigate(['/contacts']);
      }
      else {
      	this.router.navigate(['/auth/login']);	
      }
      
  }

  ngOnInit() {
  }

}
