import { Injectable } from '@angular/core';
 

@Injectable()

export class AlertService {

  public alertMessage:string;
  public alertMessageType:string;

	constructor() { }

  setMessage(message: string, type : string) {

      this.alertMessage = message;
      this.alertMessageType = type;
      setTimeout(()=> {
            this.alertMessage = '';
            this.alertMessageType = '';
      },5000);
  }

  getMessage(message: string, type : string) {
      return {message : this.alertMessage, type : this.alertMessageType};
  }

  hasFlash(){
    return (this.alertMessage && this.alertMessageType) ? 1 : 0;

  }
  

}