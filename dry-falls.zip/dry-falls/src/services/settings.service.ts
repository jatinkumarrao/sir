import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
 
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { map, catchError } from 'rxjs/operators';

import { API_ENDPOINT } from '../config'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()

export class SettingsService {

  public loginStatus = false; 
  
	constructor(private http: HttpClient) { }
  
  getSettings(userId : string) {
       
      return this.http.get(API_ENDPOINT+'/settings/' + userId, httpOptions)
        .pipe(
            map(settings => {
                return settings;
            }),
            catchError(this.handleError)
        );
  }

  updateSettings(userId,data){

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/settings/update/'+userId, body, httpOptions);

  }

  private handleError(error: HttpErrorResponse) {
      console.error('server error:', error);
      if (error.error instanceof Error) {
          const errMessage = error.error.message;
          return Observable.throw(errMessage);
      }
      return Observable.throw(error || 'Node.js server error');
  }
  

}