import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { map, catchError } from 'rxjs/operators';
 
import { API_ENDPOINT } from '../config'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()


export class EmailTemplateService {

	constructor(private http: HttpClient) { }
    
  getTemplates(userId, start:number, limit:number) {
       
      return this.http.get(API_ENDPOINT+'/templates/'+userId+'/'+start+'/'+limit, httpOptions)
        .pipe(
            map(templates => {
                return templates;
            }),
            catchError(this.handleError)
        );
  }

  getTemplate(id) {
      return this.http.get(API_ENDPOINT+'/template/'+id, httpOptions)
      .pipe(
            map(template => {
                return template;
            }),
            catchError(this.handleError)
      );    
  }


  addTemplate(userId,data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/templates/add/'+userId, body, httpOptions);

  }
  
  updateTemplate(id,data){
      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/templates/update/'+id, body, httpOptions);
  }


  deleteTemplate(id) {

      let body = JSON.stringify({id : id});
      return this.http.post(API_ENDPOINT+'/templates/delete', body, httpOptions);
      
  }


  private handleError(error: HttpErrorResponse) {
        console.error('server error:', error);
        if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return Observable.throw(errMessage);
        }
        return Observable.throw(error || 'Node.js server error');
  }




}