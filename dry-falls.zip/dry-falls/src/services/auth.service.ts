import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
 
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { map, catchError } from 'rxjs/operators';

import { API_ENDPOINT } from '../config'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()

export class AuthService {

  public loginStatus = false; 
  
	constructor(private http: HttpClient) { }
  
  login(data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/auth/login',body, httpOptions);

  }

  register(data) {

    let body = JSON.stringify(data);
    return this.http.post(API_ENDPOINT+'/auth/register', body, httpOptions);

  }

  changePassword(data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/auth/updatepassword',body, httpOptions);

  }


  forgotPassword(data) {
    
      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/auth/forgotPassword',body, httpOptions);

  }

  resetPassword(data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/auth/resetPassword',body, httpOptions);

  }

  updateProfile(data){

    let body = JSON.stringify(data);
    return this.http.post(API_ENDPOINT+'/auth/updateprofile',body, httpOptions)
        .pipe(
            map(user => {
                return user;
            }),
            catchError(this.handleError)
        );

  }

  isAuthenticated(){

     return (localStorage.getItem('user')) ? true : false;
  }
 
  logOut(){

      localStorage.removeItem('user');
   
  }

  setLoginStatus(staus: boolean) {

      this.loginStatus = staus; 
  }

  getLoginStatus() {
      return this.loginStatus;
  }

  user(){
    var userObject = localStorage.getItem('user');
    return JSON.parse(userObject);

  }

  private handleError(error: HttpErrorResponse) {
        console.error('server error:', error);
        if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return Observable.throw(errMessage);
        }
        return Observable.throw(error || 'Node.js server error');
  }
  

}