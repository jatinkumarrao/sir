import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { map, catchError } from 'rxjs/operators';
 
import { API_ENDPOINT } from '../config'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()

export class CampaignService {

	constructor(private http: HttpClient) { }
    
  getCampaigns(userId, start:number, limit:number,q:string) {
       
      return this.http.get(API_ENDPOINT+'/campaigns/'+userId+'/'+start+'/'+limit+'/'+q, httpOptions)
        .pipe(
            map(campaigns => {
                return campaigns;
            }),
            catchError(this.handleError)
        );
  }

  addCampaign(userId,data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/campaigns/add/'+userId, body, httpOptions);

  }
  
  updateCampaign(id,data){
  	  let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/campaign/update/'+id, body, httpOptions);
  }

  getCampaign(id) {

      return this.http.get(API_ENDPOINT+'/campaign/'+id, httpOptions)
      .pipe(
            map(campaign => {
                return campaign;
            }),
            catchError(this.handleError)
      );
      
  }

  deleteCampaign(id) {

      let body = JSON.stringify({id : id});
      return this.http.post(API_ENDPOINT+'/campaign/delete', body, httpOptions);
      
  }

  deleteMany(data) {

      let body = JSON.stringify({ids : data});
      return this.http.post(API_ENDPOINT+'/campaign/deleteMany', body, httpOptions);
  }


  sendMail(data){

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/campaign/sendMail', body, httpOptions);

  }


  getCampaignCopyNo(userId, q:string) {
       
      return this.http.get(API_ENDPOINT+'/campaign/copyno/'+userId+'/'+q, httpOptions)
        .pipe(
            map(campaigns => {
                return campaigns;
            }),
            catchError(this.handleError)
        );
  }

  getHistories(id, start:number, limit:number) {
       
      return this.http.get(API_ENDPOINT+'/campaign/histories/'+id+'/'+start+'/'+limit, httpOptions)
      .pipe(
          map(histories => {
                return histories;
          }),
          catchError(this.handleError)
      );
  }

  getHistorLog(tag:string) {
       
      return this.http.get(API_ENDPOINT+'/campaign/logs/'+tag, httpOptions)
      .pipe(
          map(logs => {
              return logs;
          }),
          catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
      console.error('server error:', error);
      if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return Observable.throw(errMessage);
      }
      return Observable.throw(error || 'Node.js server error');
  }


}