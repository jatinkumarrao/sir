import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { map, catchError } from 'rxjs/operators';
 


import { API_ENDPOINT } from '../config'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()

export class ListService {

	constructor(private http: HttpClient) { }
    
  getLists(userId, start:number, limit:number,q:string) {
       
      return this.http.get(API_ENDPOINT+'/lists/'+userId+'/'+start+'/'+limit+'/'+q, httpOptions)
        .pipe(
            map(lists => {
                return lists;
            }),
            catchError(this.handleError)
        );
  }

  addList(userId,data) {

      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/lists/add/'+userId, body, httpOptions);

  }
  
  updateList(id,data){
  	  let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/list/update/'+id, body, httpOptions);
  }

  getList(id) {

      return this.http.get(API_ENDPOINT+'/list/'+id, httpOptions)
      .pipe(
            map(list => {
                return list;
            }),
            catchError(this.handleError)
      );
      
  }

  getContacts(id) {

      return this.http.get(API_ENDPOINT+'/list/contacts/'+id, httpOptions)
      .pipe(
            map(contacts => {
                return contacts;
            }),
            catchError(this.handleError)
      );
      
  }

  addContacts(id,data){
      let body = JSON.stringify(data);
      return this.http.post(API_ENDPOINT+'/list/addContacts/'+id, body, httpOptions);

  }

  deleteList(id) {

      let body = JSON.stringify({id : id});
      return this.http.post(API_ENDPOINT+'/list/delete', body, httpOptions);
      
  }

  deleteMany(data) {

      let body = JSON.stringify({ids : data});
      return this.http.post(API_ENDPOINT+'/list/deleteMany', body, httpOptions);
      
  }

  private handleError(error: HttpErrorResponse) {
      console.error('server error:', error);
      if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return Observable.throw(errMessage);
      }
      return Observable.throw(error || 'Node.js server error');
  }




}