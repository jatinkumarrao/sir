// Set up
var express  = require('express');
const expressOasGenerator = require('express-oas-generator');
var app = express();  // create our app w/ express
expressOasGenerator.init(app, {});

var mongoose = require('./connection');   // mongoose for mongodb
var Schema = mongoose.Schema;
var bodyParser = require('body-parser'); 
var cors = require('cors');
var multer = require('multer');


var api_key = 'key-594fd5cb222086e4d484bcb335a0d18b';
var domain = 'webforhike.com';
var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});

var port = process.env.PORT || 8080;

app.use('/uploads', express.static(__dirname + '/uploads'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


var UserImagesSchema = new Schema({
    user_id : { type: String,required: true},
    name : { type: String,required: true}
});

var UserImages = mongoose.model('user_images', UserImagesSchema);
 
app.use(function(req,res,next){

    var _send = res.send;
    var sent = false;
    res.send = function(data){
        if(sent) return;
        _send.bind(res)(data);
        sent = true;
    };
    next();
    
}); 
 



app.use(function(req, res, next) {
   res.header("Access-Control-Allow-Origin", "*");
   res.header('Access-Control-Allow-Methods', 'POST, PUT, OPTIONS, DELETE, GET');
   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   next();
});
 
require('./routes/contacts')(app, mailgun);  
require('./routes/auth')(app, mailgun);
require('./routes/templates')(app);
require('./routes/lists')(app);  
require('./routes/campaigns')(app, mailgun);  
require('./routes/settings')(app); 

app.get('/', function(req, res) {
	res.status(200).send({success : true});
});

app.get('/images/:userid', function(req, res) {

  var userid = req.params.userid;
  UserImages.find({'user_id': userid }, function(err, images) {
      if (err){
          res.send(err)
      }
      res.json({data:images});

  });

});


	var storage = multer.diskStorage({ //multers disk storage settings
	  destination: function (req, file, cb) {
	        cb(null, './uploads/');
	  },
	  filename: function (req, file, cb) {
	        var datetimestamp = Date.now();
	        cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1]);
	  }
	});

  var upload = multer({ //multer settings
      storage: storage
  }).single('file');

  app.post('/upload', function(req, res) {

      upload(req,res,function(err){
          if(err){
               res.json({error_code:1,err_desc:err});
               return;
          }
          var data = {user_id : req.body.user_id , name : req.file.filename };
          UserImages.create(data, function(err, image) {

              if(err){ 
                  res.status(500).send(err);
              }
              else{
                  res.json({image});
              }
              
          }); 

      });
  });

app.listen(port);

module.exports.app = app;

console.log("App listening on port" + port );