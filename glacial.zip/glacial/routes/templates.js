var Template = require('../models/template');

let templateRouts = function(app,mailgun) {
     
    app.get('/templates/:userid/:skip/:limit', function(req, res) {
         
        var userid = req.params.userid;
        var skip = parseInt(req.params.skip);
        var limit = parseInt(req.params.limit);

        Template.count({'user_id': userid }, function( err, count){

            Template.find({'user_id': userid }, function(err, templates) {

                if (err){
                    res.send(err)
                }
                else{
                  res.json({totalTemplates : count, data :  templates});
                }

            }).sort({_id : -1}).skip(skip).limit(limit);

        });
        

    });

    app.get('/template/:id', function(req, res) {
        
        Template.findById(req.params.id, function(err, contact) {
          if (err){
              res.send(err)
          }
          res.json(contact);
        });

    });

    app.post('/templates/update/:id', function(req, res) {
        
        var content = JSON.stringify(req.body.content);
        var templateData = {data : content};

        Template.findByIdAndUpdate(req.params.id, templateData, function(err, template) {
          if (err){
              res.status(400).send(err)
          }
          res.json(template);
        });

    });

    app.post('/templates/add/:userid', function(req, res){
      
      var userid = req.params.userid;
      var content = JSON.stringify(req.body.content);
      var templateData = {user_id : userid, data : content};
 
      Template.create(templateData, function(err, template) {

          if(err){ 
              res.status(400).send(err);
          }
          else{
              res.json(template);
          }
          
      }); 
        
    });


    app.post('/template/delete', function(req, res){
      
      Template.findByIdAndRemove(req.body.id, (err, contact) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "Template successfully deleted",
            };

            res.status(200).send(response);
          }

      }); 

    });


}  
 
module.exports = templateRouts;