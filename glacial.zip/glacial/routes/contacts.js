var Contact = require('../models/contact');
var List = require('../models/list');
var ListContact = require('../models/listContact');

let contactRouts = function(app,mailgun) {
     
    app.get('/contacts/:userid/:skip/:limit/:q?', function(req, res) {
         
        var userid = req.params.userid;
        var skip = parseInt(req.params.skip);
        var limit = parseInt(req.params.limit);
        var q = req.params.q;
       
        if(typeof(q) != 'undefined' && q != 'null'){
          limit = 10000;
          q = q.toLowerCase();
        }
 
        Contact.count({'user_id': userid }, function( err, count){
              
             Contact.find({'user_id': userid }, function(err, contacts) {
              if (err){
                  res.send(err)
              }
              else{

                if(typeof(q) != 'undefined' && q != 'null'){
                    var data = [];
                    contacts.forEach(function(contact) {
                        if(contact.first_name.toLowerCase().indexOf(q) >=0 ||
                          contact.last_name.toLowerCase().indexOf(q) >=0 || 
                          contact.email.toLowerCase().indexOf(q) >=0 ) {
                          data.push(contact);
                        }
                    });
                    res.json({totalContacts : data.length, data :  data });
                }
                else{
                  res.json({totalContacts : count, data :  contacts});
                }
                
              }

            }).sort({_id : -1}).skip(skip).limit(limit);

        })


    });

    app.get('/contact/:id', function(req, res) {
        
        Contact.findById(req.params.id, function(err, contact) {
          if (err){
              res.send(err)
          }
          res.json(contact);
        });

    });

    app.post('/contact/update/:id', function(req, res) {
        
        var data = req.body;
        data.updated_at = Date.now();

        Contact.findByIdAndUpdate(req.params.id, data, function(err, contact) {
          if (err){
              if(err.code === 11000) {
                res.status(400).send({ succes: false, message: 'Email already exist!' });
              }
              else{
                res.status(400).send(err);
              }
          }
          res.json(contact);
        });



    });

    app.post('/contacts/add/:userid', function(req, res){
      
      var userid = req.params.userid;
      var data = req.body;
      data.user_id = userid;

      Contact.create(data, function(err, contacts) {

          if(err){ 
              if(err.code === 11000) {
                res.status(400).send({ succes: false, message: 'Email already exist!' });
              }
              else{
                res.status(400).send(err);
              }
          }
          else{
              res.json(contacts);
          }
          
      }); 
        
    });


    app.post('/contacts/delete', function(req, res){
      
      Contact.findByIdAndRemove(req.body.id, (err, contact) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "Contact successfully deleted",
            };

            res.status(200).send(response);
          }

      }); 

    });

    app.post('/contacts/deleteMany', function(req, res){
      
      let ids = req.body.ids;
      Contact.remove({_id: {$in: ids}}, (err, contact) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "Contact successfully deleted",
            };

            res.status(200).send(response);
            
          }

      }); 

    });

    app.post('/contacts/import/:userid/:listid?', function(req, res){
      
      var userid = req.params.userid;
      var listid = req.params.listid;
      var data = req.body;
      var isValidXlxs = true;
      var contactsData = [];
      
      if(data.length) {

          data.forEach(function(contact) {

            if( typeof(contact.Email) === "undefined" || 
                typeof(contact.Firstname) === "undefined" || 
                typeof(contact.Lastname) === "undefined" || 
                typeof(contact.Mobile) === "undefined" )
            {

                isValidXlxs = false;
            }
            else {

              var contact = {
                user_id : userid, 
                email : contact.Email,
                first_name : contact.Firstname,
                last_name : contact.Lastname,
                mobile : contact.Mobile
              };

              contactsData.push(contact);

            }
               
          });

      }

      if(!isValidXlxs || !contactsData.length){
          res.status(400).send({ succes: false, message : 'Invalid file!' });
      }

      else {
 
          Contact.create(contactsData, function(err, contacts) {
              if (err){ 
                  if (err.code === 11000) {
                    res.status(400).send({ succes: false, message: 'Contact already exist!' });
                  }
                  else {
                    res.status(400).send(err);
                  }
              }
              else {

                if(listid){
                  
                  var listData = [];
                  contacts.forEach(function(contact){
                    listData.push({contact_id : contact._id, list_id:listid});
                  });

                  ListContact.create(listData, function (err, listcontacts) {
                    if (err) {
                      res.send(err);
                    }

                    List.findById(listid, function(err, list) {

                      list.contacts = list.contacts + listData.length;

                      list.save(function (err, list) {
                          if (err) {
                            res.send(err);
                          }
                          res.status(200).send({stats : true, message : 'Contacts imported successfully.'});
                      });
                      
                    });

                  });

                }
                else{
                    res.json(contacts);
                }

              }
              
          }); 
        
      }

    });


    app.post('/contacts/send-email/:userid', function(req, res) {

        var userid = req.params.userid;

        Contact.find({'user_id': userid }, function(err, contacts) {
          
          if (err){
              res.send(err);
          }

          contacts.forEach(function(contact) {

              var data = {
                from: 'Excited User <me@samples.mailgun.org>',
                to: contact.email,
                subject: 'Hello',
                text: 'Testing some Mailgun awesomeness!'

              };
               
              mailgun.messages().send(data, function (error, body) {
                console.log(body);
              });

          });
          
          res.send({ succes: true, message: 'Email sent successfully.' });

        });


    });

     
}

module.exports = contactRouts;