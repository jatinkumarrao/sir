var Settings = require('../models/settings');

let settingRouts = function(app) {
     
    app.get('/settings/:userid', function(req, res) {
         
        var userid = req.params.userid;

        Settings.findOne({ 'user_id': userid }, function (err, settings) {
            
            if (err){
              res.send(err)
            }

            res.json(settings);

        });

    });

    app.post('/settings/update/:userid', function(req, res) {
        
        var userid = req.params.userid;

        Settings.findOne({ 'user_id': userid }, function (err, settings) {

            if (err){
                res.send(err)
            }

            if (!settings){

              data = req.body;
              data.user_id = userid;

              var newSettings = new Settings(req.body);
              newSettings.save(function(err){
                  if (err){
                      res.send(err)
                  }
                  else{
                     res.json(newSettings);
                  }
              });

            }
            else{
                settings.from_name = req.body.from_name;
                settings.from_email = req.body.from_email;
                settings.reply_to = req.body.reply_to;

                settings.save(function(err){
                  if (err){
                      res.send(err)
                  }
                  else{
                     res.json(settings);
                  }

                });

            }

        });

    });
     
}

module.exports = settingRouts;