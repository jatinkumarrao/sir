var _ = require('lodash');

var User = require('../models/user');

let userRouts = function(app, mailgun) {
     
    app.post('/auth/register', function(req, res) {
         
        var user = new User({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            password: req.body.password 
        });

        user.setPassword(function(err, password) {
            if (err) throw err;
        });

        user.save(function(err) {

            if (err){
                if(err.code === 11000) {
                  res.status(400).send({ succes: false, message: 'Email already exist!' });
                }
                else{
                  res.status(400).send(err)  
                }
                
            }
            else {
              const response = {
                message: "Account created successfully ",
              };
              res.status(200).send(response);
            }
            
        });

    });

    app.post('/auth/login', function(req, res) {
      
      var password = req.body.password;

      User.findOne({email : req.body.email}, (err, user) => {
          
          if(user){
            user.validatePassword(password,function(err, isMatch) {
                
                if(err) {
                  res.status(400).send(err);

                }
                else{
                  const response = _.pick(user, ['_id', 'email','first_name','last_name']);
                  res.send(response);
                   
                }

            });
          }
          else {
            res.status(400).send({ succes: false, message: 'Invalid login credentials' });
            
          }
 
      });
       
    });


    app.post('/auth/updateprofile', function(req, res) {

        User.findOne({_id : req.body.id}, (err, user) => {
            if(err) {
              res.status(400).send(err);
            }
            else{
              user.first_name = req.body.first_name;
              user.last_name = req.body.last_name;
              user.save(function(err) {
                if (err){
                  res.status(400).send(err)
                }
                else {
                  const response = _.pick(user, ['_id', 'email','first_name','last_name']);

                  res.status(200).send({
                      succes: true,  
                      message: 'Profile has been updated successfully',
                      data : user 

                  });
                }
                  
              });

            }

        });

    });

    app.post('/auth/updatepassword', function(req, res) {
      
      var oldpassword = req.body.oldpassword;
      var password = req.body.password;

      User.findOne({email : req.body.email}, (err, user) => {
          
          if(user){
            user.validatePassword(oldpassword,function(err, isMatch) {
                
              if(err) {
                res.status(400).send({ succes: false, message: 'Invalid old password' });
              }
              else{

                user.password = password;

                user.setPassword(function(err, password) {
                    if (err) throw err;
                }); 

                user.save(function(err) {
                  if (err){
                    res.status(400).send(err)
                  }
                  else {
                    res.status(200).send({succes: true,  message: 'Your password has been updated successfully'});
                  }
                  
                });

              }

            });
          }
          else {
            res.status(400).send({ succes: false, message: 'Invalid login credentials' });
            
          }
 
      });
       
  });


  app.post('/auth/forgotPassword', function(req, res) {
      

      User.findOne({email : req.body.email}, (err, user) => {

          if (err){
            res.send(err)
          }

          if(!user){
            res.status(400).send({ succes: false, message: 'Invalid email address' });
          }

          user.setToken(function(err, token) {
              if (err) throw err;
          });

          user.save(function(err) {

              var resetLink = req.body.resetLink+'/'+user.token;

              var data = {
                from: 'admin <me@samples.mailgun.org>',
                to: user.email,
                subject: 'reset password',
                html: 'Dear '+ user.first_name +',<br/><br/>You have requested to reset your password for the blast tool. Click the below link to move forward <br/><br/><a href="'+resetLink+'" target="_blank">'+resetLink+'</a>'

              };

              mailgun.messages().send(data, function (error, body) {
                //console.log(body);
              }); 
             

          });
           
          res.status(200).send({ succes: true, message: 'Sent mail to your email address' });

      });

  });


  app.post('/auth/resetPassword', function(req, res) {

    var password = req.body.password;

    User.findOne({token : req.body.token}, (err, user) => {

        if(!user){
          res.status(400).send({ succes: false, message: 'Invalid request' });
        }
        else{
          
          user.password = password;
          user.setPassword(function(err, password) {
              if (err) throw err;
          }); 

          user.token = '';

          user.save(function(err) {

            if (err){
              res.status(400).send(err)
            }
            else{
               res.status(200).send({succes: true,  message: 'Your password has been updated successfully'});
              
            }
            
            
          });

        }

    });

  });

      
}

module.exports = userRouts;