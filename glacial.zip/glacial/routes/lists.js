var List = require('../models/list');
var ListContact = require('../models/listContact');

let listRouts = function(app) {
     
    app.get('/lists/:userid/:skip/:limit/:q?', function(req, res) {
         
        var userid = req.params.userid;
        var skip = parseInt(req.params.skip);
        var limit = parseInt(req.params.limit);
        var q = req.params.q;
       
        if(typeof(q) != 'undefined' && q != 'null'){
          limit = 10000;
        }
 
        List.count({'user_id': userid }, function( err, count){
              
             List.find({'user_id': userid }, function(err, lists) {
              if (err){
                  res.send(err)
              }
              else{

                if(typeof(q) != 'undefined' && q != 'null'){
                    var data = [];
                    lists.forEach(function(list) {
                        if(list.name.indexOf(q) >=0 ) {
                          data.push(contact);
                        }
                    });
                    res.json({totalLists : data.length, data :  data });
                }
                else{
                  res.json({totalLists : count, data :  lists});
                }
                
              }

            }).sort({_id : -1}).skip(skip).limit(limit);

        })


    });

    app.get('/list/:id', function(req, res) {
        
        List.findById(req.params.id, function(err, list) {
          if (err){
              res.send(err)
          }
          res.json(list);
        });

    });

    app.post('/list/update/:id', function(req, res) {
        
        List.findByIdAndUpdate(req.params.id, req.body, function(err, list) {
          if (err){
              res.status(400).send(err)
          }
          res.json(list);
        });



    });

    app.post('/lists/add/:userid', function(req, res){
      
      var userid = req.params.userid;
      var data = req.body;
      data.user_id = userid;

      List.create(data, function(err, list) {

          if(err){ 
              res.send(err);
          }
          else{
              res.json(list);
          }
          
      }); 
        
    });


    app.post('/list/delete', function(req, res){
      
      List.findByIdAndRemove(req.body.id, (err, list) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "List successfully deleted",
            };

            res.status(200).send(response);
          }

      }); 

    });

    app.post('/list/deleteMany', function(req, res){
      
      let ids = req.body.ids;
      List.remove({_id: {$in: ids}}, (err, list) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "List successfully deleted",
            };

            res.status(200).send(response);
            
          }

      }); 

    });

    app.get('/list/contacts/:listid', function(req, res){

        ListContact.find({list_id : req.params.listid})
          .populate('contact_id')
          .exec(function(err, contacts) {
            
            if (err){
                res.send(err)
            }
            res.json(contacts);

        });

    });


    app.post('/list/addContacts/:listid', function(req, res){

        var listid = req.params.listid;

        List.findById(listid, function(err, list) {
            if (err) {
              res.send(err);
            }
            list.contacts = req.body.contacts.length;
            list.save(function (err, list) {
                if (err) {
                  res.send(err);
                }
            });

        });

        ListContact.remove({list_id : listid}, (err, contacts) => {

          if (err) {
            res.send(err);
          }

          ListContact.create(req.body.contacts, function (err, contacts) {
            
            if (err) {
              res.send(err);
            }

            res.status(200).send({stats : true, message : 'Contacts added successfully.'});

          });

        });

    });

}

module.exports = listRouts;