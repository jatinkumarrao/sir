var moment = require('moment');
var Campaign = require('../models/campaign');
var ListContact = require('../models/listContact');
var Contact = require('../models/contact');
var CampaignHistory = require('../models/campaignHistory');

let campaignRouts = function(app, mailgun) {
     
    app.get('/campaigns/:userid/:skip/:limit/:q?', function(req, res) {
         
        var userid = req.params.userid;
        var skip = parseInt(req.params.skip);
        var limit = parseInt(req.params.limit);
        var q = req.params.q;
       
        if(typeof(q) != 'undefined' && q != 'null'){
          limit = 10000;
        }
 
        Campaign.count({'user_id': userid }, function( err, count){
              
             Campaign.find({'user_id': userid }, function(err, campaigns) {
              if (err){
                  res.send(err)
              }
              else{

                if(typeof(q) != 'undefined' && q != 'null'){
                    var data = [];
                    campaigns.forEach(function(campaign) {
                        if(campaign.name.indexOf(q) >=0 ) {
                          data.push(contact);
                        }
                    });
                    res.json({totalCampaigns : data.length, data :  data });
                }
                else{
                  res.json({totalCampaigns : count, data :  campaigns});
                }
                
              }

            }).sort({_id : -1}).skip(skip).limit(limit);

        })


    });

    app.get('/campaign/:id', function(req, res) {
        
        Campaign.findById(req.params.id, function(err, campaign) {
          if (err){
              res.send(err)
          }
          res.json(campaign);
        });

    });

    app.post('/campaign/update/:id', function(req, res) {
        
        Campaign.findByIdAndUpdate(req.params.id, req.body, function(err, campaign) {
          if (err){
              res.status(400).send(err)
          }
          res.json(campaign);
        });

    });

    app.post('/campaigns/add/:userid', function(req, res){
      
      var userid = req.params.userid;
      var data = req.body;
      data.user_id = userid;

      Campaign.create(data, function(err, campaign) {

          if(err){ 
              res.send(err);
          }
          else{
              res.json(campaign);
          }
          
      }); 
        
    });


    app.post('/campaign/delete', function(req, res){
      
      Campaign.findByIdAndRemove(req.body.id, (err, campaign) => {
          if (err) {
            res.status(400).send(err);
          }
          else {
            CampaignHistory.remove({campaign_id: req.body.id}, (err, campaign) => {
                if (err) {
                  res.status(400).send(err);
                }
            });

            const response = {
                message: "Campaign successfully deleted",
            };

            res.status(200).send(response);
          }

      }); 

    });

    app.post('/campaign/deleteMany', function(req, res){
      
      let ids = req.body.ids;
      Campaign.remove({_id: {$in: ids}}, (err, campaign) => {
          if (err) {
            res.status(400).send(err);
          }
          else{
            const response = {
                message: "Campaign successfully deleted",
            };

            res.status(200).send(response);
            
          }

      }); 

    });

    app.post('/campaign/sendMail', function(req, res){

        let messageData = req.body;

        ListContact.find({list_id: {$in: req.body.tolist}}, (err, lists) => {
            if (err) {
              res.send(err);
            }

            let usersids = [];

            if(lists){

                lists.forEach(function(list){
                  usersids.push(list.contact_id);
                });

                var recipients = [];
                var historyData = {
                  campaign_id : messageData.id,
                  from : messageData.email,
                  subject : messageData.subject,
                };

                CampaignHistory.create(historyData, function(err, history) {

                    if (err) {
                      res.status(400).send(err);
                    }

                    Contact.find({_id: {$in: usersids}}, (err, contacts) => {
                    
                      contacts.forEach(function(contact) {
                        
                        var data = {
                          from: `${messageData.name} <${messageData.email}>`,
                          to: contact.email,
                          subject: messageData.subject,
                          html: messageData.content,
                          'o:tracking' : 'yes',
                          'o:tag' : 'cam_'+history._id

                        };
                        
                        recipients.push({email : contact.emai, status:''});

                        mailgun.messages().send(data, function (error, body) {
                            //console.log('mail info', body);
                        });

                      });

                      history.recipients = recipients;
                      history.save(function (err, list) {
                          if (err) {
                            res.send(err);
                          }
                      });

                    });

                });

              res.status(200).send({status : true, message : 'mail sent successfully'});

            }

        });

    });


    app.get('/campaign/copyno/:userid/:from', function(req, res) {

        var userid = req.params.userid;
        var name = req.params.from;
        Campaign.count({$and: [{'user_id': userid}, {'name': new RegExp(name.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1"), "i")}]}, function(err, doc) {
            
            if (err) {
              res.send(err);
            }

            res.json(doc);

        });

    });


    app.get('/campaign/histories/:id/:skip/:limit', function(req, res) {
         
        var id = req.params.id;
        var skip = parseInt(req.params.skip);
        var limit = parseInt(req.params.limit);
       
        CampaignHistory.count({'campaign_id': id }, function( err, count){
              
             CampaignHistory.find({'campaign_id': id }, function(err, histories) {
              if (err){
                  res.send(err)
              }
              else{
                res.json({totalHistory : count, data :  histories});
              }

            }).sort({_id : -1}).skip(skip).limit(limit);

        })


    });

    app.get('/campaign/logs/:tag', function(req, res) {

      var tag = req.params.tag;
      let day   = moment().subtract(2, 'days').format('ddd');
      let daynumber  = moment().subtract(2, 'days').date();
      let month = moment().subtract(2, 'days').format('MMM');
      let year  = moment().subtract(2, 'days').format('YYYY');
      let date = day+', '+daynumber+' '+month+' '+year + ' 00:00:00 -0000';

      let queryString ={
          begin : date, //'Thu, 19 Apr 2018 00:00:00 -0000',
          ascending : 'yes',
          limit : 300,
          tags : tag
      } 

      mailgun.get('/webforhike.com/events', queryString, function (error, body) {

        res.json(body);

      });

    });
    

}

module.exports = campaignRouts;