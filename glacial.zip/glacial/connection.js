 
var mongoose = require('mongoose');   // mongoose for mongodb
mongoose.connect('mongodb://demo:demo@ds111078.mlab.com:11078/blast-tool');

// When successfully connected
mongoose.connection.on('connected', function () {  
  console.log('Mongoose default connection open');
}); 

// If the connection throws an error
mongoose.connection.on('error',function (err) {  
  console.log('Mongoose default connection error: ' + err);
});
 
module.exports = mongoose;