const assert = require('assert');
const request = require('supertest');
const app = require('./server').app;

describe('contact', function() {

    it('add should return 200 status if contact added', function(done) {
        
        request(app)
        .post('/contacts/add/5aabb1f012ff7b367aaddc07')
        .send({user_id: '5aabb1f012ff7b367aaddc07', email : 'eeravikant@nascenture.com'})
        .expect(200, done);

    });

    it('update should return 200 status if contact updated', function(done) {
        
        request(app)
        .post('/contact/update/5abdd7dcfe2a3714f54f642a')
        .send({user_id: '5aabb1f012ff7b367aaddc07', email : 'eeravikant@nascenture.com', first_name : 'ravi test 1'})
        .expect(200, done);

    });

    it('delete should return 200 status if contact deleted', function(done) {
        
        request(app)
        .post('/contacts/delete')
        .send({id: '5abdd7dcfe2a3714f54f642a'})
        .expect(200, done);

    });
      
});